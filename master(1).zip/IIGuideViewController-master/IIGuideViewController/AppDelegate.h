//
//  AppDelegate.h
//  IIGuideViewController
//
//  Created by whatsbug on 2019/8/13.
//  Copyright © 2019 whatsbug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

