# IIGuideViewController
这个组件是从我开发的一款浏览器中分离出来的，主要用于新手引导。前天该浏览器已上架到App Store，大家可以从这里下载体验：[biubiu-颜值超高的浏览器](https://apps.apple.com/cn/app/id1474593656)
# 效果预览
![图片预览](/preview.gif)

